package com.team4.compliance;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ComplianceReportingMicroservicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ComplianceReportingMicroservicesApplication.class, args);
	}

}
